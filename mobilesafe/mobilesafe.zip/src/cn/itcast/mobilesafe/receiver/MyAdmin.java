package cn.itcast.mobilesafe.receiver;

import android.app.admin.DeviceAdminReceiver;

public class MyAdmin extends DeviceAdminReceiver {

}
