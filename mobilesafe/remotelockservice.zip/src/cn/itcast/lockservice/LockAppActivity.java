package cn.itcast.lockservice;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LockAppActivity extends Activity {

	EditText editText1;
	Intent intent ; 
	 IService iService;
	 WatchDogConn conn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		editText1 = (EditText) this.findViewById(R.id.editText1);
		intent = new Intent(this,WatchDogService.class);
		conn = new WatchDogConn();
		bindService(intent,conn , BIND_AUTO_CREATE);
	}

	private class WatchDogConn implements ServiceConnection{

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			iService = IService.Stub.asInterface(service);
			
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	
	public  void submit(View view){
		String pwd  = editText1.getText().toString().trim();
		if("".equals(pwd)){
			Toast.makeText(this, "����������", 1).show();
			return ;
		}else{
			// ���������������Ϊ123
			if("123".equals(pwd)){
				finish();
				//������������ȷ��ʱ�� ���ǵ���service����ķ��� ֪ͨϵͳֹͣ��Ӧ�İ����ı���
				Intent intent = getIntent();
				if(intent!=null){
				String packname =	intent.getStringExtra("packname");
				try {
					iService.callStopProtectApp(packname);
				} catch (RemoteException e) {
					e.printStackTrace();
				}
				}
			
			}
		}
		
	}
	// �����ֻ��ĺ��˰�ť 
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

			if(keyCode == KeyEvent.KEYCODE_BACK){
				
				return true;

		}
		return super.onKeyDown(keyCode, event);
	}
	@Override
	protected void onDestroy() {
		unbindService(conn);
		super.onDestroy();
	}
	
	
	
	
}
