package cn.itcast.lockservice.test;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.AndroidTestCase;

public class TestAppProvider extends AndroidTestCase {

	public void testMobileSafeAppProvider() throws Exception{
		Uri uri = Uri.parse("content://cn.itcast.mobilesafe.lockappprovider/allapp");
		Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
		while(cursor.moveToNext()){
			String packname = cursor.getString( cursor.getColumnIndex("packname"));
			System.out.println(packname);
		}
		cursor.close();
	}
	
	public void testAddPackname() throws Exception{
		Uri uri = Uri.parse("content://cn.itcast.mobilesafe.lockappprovider/insertapp");
		ContentValues values = new ContentValues();
		values.put("packname", "cn.itcast.haha");
		getContext().getContentResolver().insert(uri, values);
	
	}
	public void testDeletePackname() throws Exception{
		Uri uri = Uri.parse("content://cn.itcast.mobilesafe.lockappprovider/deleteapp");
		getContext().getContentResolver().delete(uri, null, new String[]{"cn.itcast.lock2"});
	}
}
